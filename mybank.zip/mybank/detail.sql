-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2022 at 09:25 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `detail`
--

CREATE TABLE `detail` (
  `Customer_Name` varchar(100) NOT NULL,
  `Account_Number` int(100) NOT NULL,
  `Phone_no` int(20) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `DOB` date NOT NULL,
  `Address` varchar(100) NOT NULL,
  `E_mail_address` varchar(20) NOT NULL,
  `Initial_deposit` int(100) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `balance` float(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `detail`
--

INSERT INTO `detail` (`Customer_Name`, `Account_Number`, `Phone_no`, `Gender`, `DOB`, `Address`, `E_mail_address`, `Initial_deposit`, `pic`, `balance`) VALUES
('neha', 0, 387645, 'female', '2022-04-05', 'jalandhar\n\n', 'neha@gmail.com', 0, '1649239286bg.jpg', 4000.00),
('priyanka', 1, 9838736, 'female', '1999-04-12', 'jalandhar\n', 'abc@gmail.com', 15000, 'defaultimage.png', 900.00),
('rohit', 2, 45, 'male', '2000-02-02', 'goa\n', 'abcz@yahoo.com', 200, '16491435564.jpg', 0.00),
('sarbjit', 11, 654378387, 'female', '2022-04-06', 'bange\n', 'sarb@gmail.com', 5000, 'defaultimage.png', 500.00),
('rohan', 12, 907486, 'male', '2022-04-04', 'dehli\nee\n', 'abc@gmail.com', 1000, 'defaultimage.png', 1000.00),
('rohanqq', 13, 907486, 'male', '2022-04-04', 'dehli\n\n', 'abc@gmail.com', 1000, '1649486443flower.jpg', 1000.00),
('wer', 333, 1231231231, 'female', '2022-04-13', 'sdfsd\n', 's@gmail.com', 1000, 'defaultimage.png', 1000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail`
--
ALTER TABLE `detail`
  ADD PRIMARY KEY (`Account_Number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
