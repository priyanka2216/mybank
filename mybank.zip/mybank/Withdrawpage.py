from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Combobox, Treeview
import pymysql as pymysql
class WithdrawClass:
    def __init__(self, pwindow):
        # self.window = Tk() #creat independent windoW
        # self.window = pwindow  # now both window are same
        self.window = Toplevel(pwindow)  # now both acts as parent to child window(student)
        self.window.winfo_screenwidth()
        self.window.winfo_screenheight()
        self.window.geometry("%dx%d+%d+%d" % (1000, 700, 0, 0))
        self.headlbl = Label(self.window, text="Withdraw", font=("Algerian ITC", 40, "bold"))
        #__________Widgets________________________#
        self.L1 = Label(self.window, text="Account Number")
        self.L2 = Label(self.window, text="Customer Name")
        self.L3 = Label(self.window, text="Balance")
        self.L4 = Label(self.window, text="Amount")
        self.b1 = Button(self.window, text="Fetch",command=self.fetch_record)
        self.b2 = Button(self.window, text="Withdraw",command=self.update_data)
        self.t1 = Entry(self.window)
        self.t2 = Entry(self.window)
        self.t3 = Entry(self.window)
        self.t4 = Entry(self.window)
        #_______________________Placement___________________________
        self.headlbl.place(x=0, y=15)
        x1 = 10
        y1 = 100
        x_diff = 100
        y_diff = 50
        self.L1.place(x=x1, y=y1)
        self.t1.place(x=x1 + x_diff, y=y1)
        self.b1.place(x=x1 + x_diff + x_diff + 50, y=y1, width=100)
        y1 += y_diff
        self.L2.place(x=x1, y=y1)
        self.t2.place(x=x1 + x_diff, y=y1)
        y1 += y_diff
        self.L3.place(x=x1, y=y1)
        self.t3.place(x=x1 + x_diff, y=y1)
        y1 += y_diff
        self.L4.place(x=x1, y=y1)
        self.t4.place(x=x1 + x_diff, y=y1)
        y1+=y_diff
        self.b2.place(x=x1 + x_diff, y=y1, width=100)
        self.b2['state']='disable'
    def database_connection(self):
        myhost = "localhost"
        mydb = "my_bank"
        myuser = "root"
        mypassword = ""
        try:
            self.conn = pymysql.connect(host=myhost, db=mydb, user=myuser, password=mypassword)
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Connection Error", "Database connection Error : " + str(e), parent=self.window)
    def fetch_record(self):
        c1 = self.t1.get()
        self.database_connection()
        self.clearpage()
        try:
            qry = "select * from detail where Account_Number=%s"
            row_count = self.curr.execute(qry, (c1))
            data = self.curr.fetchone()
            if (data):
                self.t1.insert(0, data[1])
                self.t2.insert(0, data[0])
                self.t3.insert(0, data[9])
                self.b2['state']='normal'
            else:
                messagebox.showwarning("Warning", "No Customer Found for this Account_Number", parent=self.window)
                self.clearpage()
        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : " + str(e), parent=self.window)

    def update_data(self):
        self.database_connection()
        if(float(self.t3.get())<float((self.t4.get()))):
            messagebox.showwarning("Insufficent balance","deposit money first",parent=self.window)
            return


        try:
            b = float(self.t3.get())-float(self.t4.get())
            qry = "update detail set balance=%s where Account_number = %s"
            row_count = self.curr.execute(qry, (b, self.t1.get()))
            data = self.curr.fetchone()
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Success", "Rs {} Withdraw successfully ".format(self.t4.get())
                                    , parent=self.window)
                self.clearpage()
            else:

                messagebox.showwarning("Failure", "Check Account number", parent=self.window)
        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : " + str(e), parent=self.window)
        # ******************************Fetch_data******************************************
    def clearpage(self):
        self.t1.delete(0,END)
        self.t2.delete(0,END)
        self.t3.delete(0,END)
        self.t4.delete(0,END)
        self.b2['state'] = 'disable'

if __name__ == '__main__':
    d_window = Tk()
    WithdrawClass(d_window)
    d_window.mainloop()

