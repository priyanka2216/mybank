from tkinter import *
from tkinter import messagebox
from tkinter.filedialog import askopenfilename
from tkinter.ttk import Combobox, Treeview
from tkcalendar import DateEntry
from PIL import Image,ImageTk
from tkinter.filedialog import  askopenfilename
import pymysql as pymysql
class Customerclass:
    default_img = "defaultimage.png"
    def __init__(self, pwindow):
        # self.window = Tk() #creat independent windoW
        self.old_name = None
        self.window = pwindow  # now both window are same
        self.window = Toplevel(pwindow)  # now both acts as parent to child window(student)
        self.window.winfo_screenwidth()
        self.window.winfo_screenheight()
        self.window.state("zoomed")
        #self.window.geometry("%dx%d+%d+%d" % (1000, 700, 0, 0))
        self.headlbl = Label(self.window, text="Customer", font=("Algerian ITC", 50, "bold"))
        # ________________Heading____________________________

        self.L1 = Label(self.window, text=" Customer_Name")
        self.L2 = Label(self.window, text="Account_Number")
        self.L3 = Label(self.window, text="Phone_no")
        self.L4 = Label(self.window, text="Gender")
        self.L5 = Label(self.window, text="DOB")
        self.L6 = Label(self.window, text="Address")
        self.L7 = Label(self.window, text="E_mail_address")
        self.L8 = Label(self.window, text="Initial Deposit")
        # _____________Entry______________________
        self.t1 = Entry(self.window)
        self.t2 = Entry(self.window)
        self.t3 = Entry(self.window)

        self.v1 = StringVar()
        self.r1 = Radiobutton(self.window, text="Male", value="male", variable=self.v1)
        self.r2 = Radiobutton(self.window, text="Female", value="female", variable=self.v1)
        self.t5 = Entry(self.window)
        self.t5 = DateEntry(self.window,width=12,background='darkblue',foreground='white',borderwidth=2,
                            date_pattern='y-mm-dd')
        self.t6 = Text(self.window, width=15, height=3)
        self.t7 = Entry(self.window)
        self.t8 = Entry(self.window)

        self.b1 = Button(self.window, text="Save_Account", command=self.save_data)
        self.b2 = Button(self.window, text="Update_Account", command=self.update_data)
        self.b3 = Button(self.window, text="Delete_Account", command=self.delete_data)
        self.b4 = Button(self.window, text="Fetch", command=self.fetch_data)
        self.b5 = Button(self.window, text="search", command=self.search_data)
        self.b6 = Button(self.window, text="Upload", command=self.get_image)

        self.imglbl = Label(self.window, borderwidth=2, relief='groove')

        # ----------------- table--------------------------

        self.tablearea = Frame(self.window)
        self.mytable = Treeview(self.tablearea, columns=('c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8'), height=10)
        self.mytable.heading('c1', text='Customer_Name')
        self.mytable.heading('c2', text='Account_Name')
        self.mytable.heading('c3', text='Phone_no')
        self.mytable.heading('c4', text='Gender')
        self.mytable.heading('c5', text='DOB')
        self.mytable.heading('c6', text='Address')
        self.mytable.heading('c7', text='E_mail_address')
        self.mytable.heading('c8', text='Initial Deposit')
        self.mytable['show'] = 'headings'
        self.mytable.column("#1", width=100, anchor='center')
        self.mytable.column("#2", width=100, anchor='n')
        self.mytable.column("#3", width=100, anchor='e')
        self.mytable.column("#4", width=100, anchor='center')
        self.mytable.column("#5", width=60, anchor='center')
        self.mytable.column("#6", width=200, anchor='center')
        self.mytable.column("#7", width=200, anchor='center')
        self.mytable.column("#8", width=70, anchor='center')
        self.mytable.pack()
        self.mytable.bind("<ButtonRelease-1>", lambda e: self.fetch_pk())

        # __________________Placement_____________________
        self.headlbl.place(x=0, y=0)
        x1 = 10
        y1 = 100

        x_diff = 100
        y_diff = 50

        self.L1.place(x=x1, y=y1)
        self.t1.place(x=x1 + x_diff, y=y1)
        self.b4.place(x=x1 + x_diff + x_diff + 50, y=y1, width=50)
        self.tablearea.place(x=x1 + x_diff + x_diff+x_diff + 50, y=y1)

        y1 += y_diff
        self.L2.place(x=x1, y=y1)
        self.t2.place(x=x1 + x_diff, y=y1)
        self.b5.place(x=x1 + x_diff + x_diff + 50, y=y1, width=50)

        y1 += y_diff
        self.L3.place(x=x1, y=y1)
        self.t3.place(x=x1 + x_diff, y=y1)
        self.r1.place(x=x1 + x_diff, y=y1)
        self.r2.place(x=x1 + x_diff + x_diff, y=y1)

        y1 += y_diff
        self.L4.place(x=x1, y=y1)
        self.r1.place(x=x1 + x_diff, y=y1)
        self.r2.place(x=x1 + x_diff + x_diff, y=y1)

        y1 += y_diff
        self.L5.place(x=x1, y=y1)
        self.t5.place(x=x1 + x_diff, y=y1)

        y1 += y_diff
        self.L6.place(x=x1, y=y1)
        self.t6.place(x=x1 + x_diff, y=y1)
        y1 += y_diff

        self.imglbl.place(x=x1+400, y=y1,width=150,height=150)
        self.b6.place(x=x1 + 400, y=y1+150,width=150)

        y1 += y_diff
        self.L7.place(x=x1, y=y1)
        self.t7.place(x=x1 + x_diff, y=y1)


        y1 += y_diff
        self.L8.place(x=x1, y=y1)
        self.t8.place(x=x1 + x_diff, y=y1)

        y1 += y_diff
        self.b3.place(x=x1, y=y1, width=90)
        self.b2.place(x=x1 + 150, y=y1, width=90)
        self.b1.place(x=x1 + 300, y=y1, width=90)
        # self.b4.place(x=x1 + 200, y=y1, width=50)
        # self.b5.place(x=x1 + 200, y=y1, width=50)
        self.clearpage()
        self.window.mainloop()

    def get_image(self):
        self.filename = askopenfilename(file=[("All pictures", "*.png;*.jpg;*.jpeg"), ("PNG Images ", "*.png"), ("JPG Images ", "*.jpg")])
        print("filename = ", self.filename)
        if self.filename != "":
                # pick image and resize it
           self.img1 = Image.open(self.filename)
           self.img1 = self.img1.resize((150, 150), Image.ANTIALIAS)

                # making it photoimage for label(as label accepts only this type0
           self.img2 = ImageTk.PhotoImage(self.img1)
           self.imglbl.config(image=self.img2)

           path = self.filename.split("/")  # extracting path from whole filename
           name = path[-1]  # getting last value(i.e. name of image)
           import time
           uniqueness = str(int(time.time()))  # making timestamp as string
           self.actual_name = uniqueness + name  # making it unique by adding time stamp
           print("name = ", self.actual_name)

    def database_connection(self):
        myhost = "localhost"
        mydb = "my_bank"
        myuser = "root"
        mypassword = ""

        try:
            self.conn = pymysql.connect(host=myhost, db=mydb, user=myuser, password=mypassword)
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Connection Error", "Database connection Error : " + str(e), parent=self.window)

    def save_data(self):

        if self.validate_check()==False:
            return
        self.database_connection()
        if self.actual_name == self.default_img:  # no image is selected
            # nothing to save in folder
            pass
        else:  # image is selected
            self.img1.save("customer_images//" + self.actual_name)  # image saved in folder
        try:
            qry = "insert into detail values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            row_count = self.curr.execute(qry, (self.t1.get(), self.t2.get(), self.t3.get(),
                                                self.v1.get(), self.t5.get(), self.t6.get('1.0', END),
                                                self.t7.get(), self.t8.get(),self.actual_name,self.t8.get()))
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Success", "Data save_Account successfully", parent=self.window)
                self.clearpage()
            else:
                messagebox.showwarning("Failure", "Check All Values", parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : " + str(e), parent=self.window)

    def update_data(self):
        if self.validate_check()==False:
            return
        self.database_connection()

        if self.actual_name==self.old_name:     # no new image is selected
            # nothing to delete or save
            pass
        else:   # new image is selected
            self.img1.save("Customer_images//"+self.actual_name)  # save image
            if self.old_name==self.default_img: # no old image was given in past
                #nothing to delete
                pass
            else:   # image was given in past
                import os
                os.remove("customer_images//"+self.old_name)
        try:
            qry = "update detail set customer_name =%s, Phone_no = %s , Gender = %s , DOB = %s , " \
                  "Address = %s , E_mail_address = %s ,Initial_deposit = %s ,pic=%s,balance=%s where Account_number = %s"
            row_count = self.curr.execute(qry, ( self.t1.get(), self.t3.get(), self.v1.get(), self.t5.get(), self.t6.get('1.0', END),
                                                self.t7.get(), self.t8.get(),self.actual_name,self.t8.get(),self.t2.get()))
            data = self.curr.fetchone()
            print(data)
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Success", "Data update_Account successfull", parent=self.window)
                self.clearpage()
            else:

                messagebox.showwarning("Falure", "Check All Values", parent=self.window)
        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : " + str(e), parent=self.window)
        # ******************************Fetch_data******************************************

    # ******************************Delete_data*********************************************

    def delete_data(self):
        ans = messagebox.askquestion("Confirmation", "Are you suru to delete_Account??'", parent=self.window)
        if ans == 'yes':
            if self.old_name == self.default_img:  # no old image was given in past
                # nothing to delete
                pass
            else:  # image was given in past
                import os
                os.remove("Customer_images//" + self.old_name)
            self.database_connection()
            try:
                qry = "delete from detail where Account_Number=%s"
                row_count = self.curr.execute(qry, (self.t2.get()))
                self.conn.commit()
                if row_count == 1:
                    messagebox.showinfo("Success", "Customer Record Delete_Account successfull", parent=self.window)
                    self.clearpage()
                else:

                    messagebox.showwarning("Failure", "Customer Record Not Delete_Account successfull",
                                           parent=self.window)
            except Exception as e:
                messagebox.showerror("Query Error", "Error while delation : " + str(e), parent=self.window)

    def fetch_pk(self):
        id = self.mytable.focus()
        # print("id = ",id)
        items = self.mytable.item(id)
        # print("item = ",items)
        myvalues = items['values']
        # print(myvalues)
        pk = myvalues[1]
        # print("pk = ",pK)
        self.fetch_data(pk)

    def fetch_data(self, pk=None):
        if pk == None:
            c1 = self.t2.get()

        else:
            c1 = pk
        self.database_connection()

        try:
            qry = "select * from detail where Account_Number=%s"
            row_count = self.curr.execute(qry, (c1))
            data = self.curr.fetchone()
            print(data)
            self.clearpage()
            if (data):
                self.t1.insert(0, data[0])
                self.t2.insert(0, data[1])
                self.t3.insert(0, data[2])
                self.v1.set(data[3])
                self.t5.insert(0, data[4])
                self.t6.insert('1.0', data[5])
                self.t7.insert(0, data[6])
                self.t8.insert(0, data[7])
                self.actual_name=data[8]
                self.old_name=data[8]
                self.imglbl.config(image=self.img2)
                self.img1 = Image.open("customer_images//" + self.actual_name)
                self.img1 = self.img1.resize((150, 150), Image.ANTIALIAS)
                self.img2 = ImageTk.PhotoImage(self.img1)
                self.imglbl.config(image=self.img2)

            else:
                messagebox.showwarning("Warning", "No Customer Found for this Account_Number", parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : " + str(e), parent=self.window)

    def clearpage(self):
        self.t1.delete(0, END)
        self.t2.delete(0, END)

        self.v1.set(None)
        self.t3.delete(0, END)
        self.t5.delete(0, END)
        self.t6.delete('1.0', END)
        self.t7.delete(0, END)
        self.t8.delete(0, END)
        self.actual_name = self.default_img
        # add default image in label
        self.img1 = Image.open("customer_images//" + self.actual_name)
        self.img1 = self.img1.resize((150, 150))
        self.img2 = ImageTk.PhotoImage(self.img1)
        self.imglbl.config(image=self.img2)

    # *********************************Search_data************************************
    def search_data(self):
        self.database_connection()
        self.mytable.delete(*self.mytable.get_children())
        try:
            qry = "select * from detail where customer_name like %s "
            row_count = self.curr.execute(qry, (self.t1.get() + "%"))
            data = self.curr.fetchall()
            if (data):
                for row in data:
                    self.mytable.insert("", END, values=row)
            else:
                messagebox.showwarning("No Record", "No Record found for this  Customer_Name ", parent=self.window)


        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : " + str(e), parent=self.window)

    def validate_check(self):
        if not (self.t1.get().isalpha()) or len(self.t1.get()) < 3:
            messagebox.showwarning("Validation Check", "Enter proper name(atleast 3 characters)",
                                   parent=self.window)
            return False
        elif not (self.t2.get().isdigit()):
            messagebox.showwarning("Validation Check", "Enter correct Account number", parent=self.window)
            return False
        elif not (self.t3.get().isdigit()) or len(self.t3.get()) != 10:
            messagebox.showwarning("Validation Check", "Enter valid phone no \n 10 digits only", parent=self.window)
            return False
        elif not (self.v1.get() == 'male' or self.v1.get() == 'female'):
            messagebox.showwarning("Input Error", "Please Select gender ", parent=self.window)
            return False
        elif (self.t5.get() == ""):
            messagebox.showwarning("Input Error", "Please Select DOB ", parent=self.window)
            return False
        elif len(self.t6.get('1.0', END)) < 3:
            messagebox.showwarning("Input Error", "Fill Address ", parent=self.window)
            return False
        elif self.t7.get().find("@") == -1 or self.t7.get().find(".") == -1:
            messagebox.showwarning("Input Error", "Write correct Email-Id ", parent=self.window)
            return False
        elif not (self.t8.get().isdigit()):
            messagebox.showwarning("Validation Check", "Enter the amount", parent=self.window)
            return False

        return True


        return True


if __name__ == '__main__':
    d_window = Tk()
    Customerclass(d_window)
    d_window.mainloop()

