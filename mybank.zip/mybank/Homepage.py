from tkinter import*
from PIL import ImageTk,Image
from Recordpage1 import Record1Class
from Depositpage import Depositclass
from Withdrawpage import WithdrawClass
from Customerpage import Customerclass
from manage_user import UserClass


class Homepageclass:
    def __init__(self,utype,uname):
        self.utype=utype
        self.uname= uname
        self.window = Tk()
        self.window.title('Bank Management System')
        W = self.window.winfo_screenwidth()
        h = self.window.winfo_screenheight()
        #methon1
        #self.window.minsize(1000,700)
        #method2
        self.window.state("zoomed")
        #self.window.geometry("%dx%d+%d+%d"%(500,600,500,300))
        self.window.option_add('*tearOff',False)
        #______________________background image_____________________#
        self.bimg1 = Image.open("bg_images/b1.jpg")
        self.bimg1 = self.bimg1.resize((W,h), Image.ANTIALIAS)
        self.bimg2 = ImageTk.PhotoImage(self.bimg1)
        self.bklbl=Label(self.window,image=self.bimg2)
        self.bklbl.place(x=0,y=0)


        #method 3
        #self.window.state("zoomed")
        self.menubar = Menu()
        self.window.config(menu=self.menubar)

        self.menu1 = Menu()
        self.menu2= Menu()
        self.menu3 = Menu()
        self.menu4 = Menu()

        self.menubar.add_cascade(menu=self.menu1,label="Details")
        self.menubar.add_cascade(menu=self.menu2, label="Transaction")
        self.menubar.add_cascade(menu=self.menu3, label="Report")
        self.menubar.add_cascade(menu=self.menu4, label="User")
    #__________________submenu1____________________________

        self.menu1.add_command(label="Customer",command=lambda :Customerclass(self.window))

    #____________________submenu2___________________________
        self.menu2.add_command(label="Deposit",command=lambda :Depositclass(self.window))

        self.menu2.add_command(label="Withdraw",command=lambda :WithdrawClass(self.window))

        # ____________________submenu2___________________________
        self.menu3.add_command(label="All_List", command=lambda: Record1Class(self.window))

        self.menu4.add_command(label="Manage User", command=lambda: UserClass(self.window))


        self.window.mainloop()
if __name__ == '__main__':
    Homepageclass("employee","emp")