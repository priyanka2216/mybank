
myhost = "localhost"
mydb = "my_bank"
myuser = "root"
mypassword = ""