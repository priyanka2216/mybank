from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Combobox, Treeview
import pymysql


class Record1Class:
    def __init__(self,pwindow):
        self.window = Toplevel(pwindow)
        w = self.window.winfo_screenwidth()
        h = self.window.winfo_screenheight()
        self.window.state('zoomed')
        self.headlbl = Label(self.window,text="Customer Record",font=("Calibri",50,'bold'))


        self.tablearea = Frame(self.window)
        self.mytable =Treeview(self.tablearea,columns=('c1','c2','c3','c4','c5','c6','c7','c8','c9'),height=20)
        self.mytable.heading('c1', text='Customer_Name')
        self.mytable.heading('c2',text='Account_Number')
        self.mytable.heading('c3',text='Phone No')
        self.mytable.heading('c4',text='Gender')
        self.mytable.heading('c5',text='DOB')
        self.mytable.heading('c6',text='Address')
        self.mytable.heading('c7',text='Email-Id')
        self.mytable.heading('c8',text='Initial_Deposit')
        self.mytable.heading('c9', text='Balance')

        self.mytable['show']='headings'
        self.mytable.column("#1",width=100,anchor='center')
        self.mytable.column("#2",width=200,anchor='center')
        self.mytable.column("#3",width=100,anchor='center')
        self.mytable.column("#4",width=100,anchor='center')
        self.mytable.column("#5",width=100,anchor='center')
        self.mytable.column("#6",width=300,anchor='center')
        self.mytable.column("#7",width=200,anchor='center')
        self.mytable.column("#8",width=200,anchor='center')
        self.mytable.column("#9", width=200, anchor='center')
        self.mytable.pack()

        self.headlbl.place(x=0,y=0)
        x1 = 10
        y1= 100
        x_diff=100
        y_diff=50
        self.tablearea.place(x=x1,y=y1)
        self.search_all_data()
        self.window.mainloop()

    def database_connection(self):
        myhost="localhost"
        mydb = "my_bank"
        myuser = "root"
        mypassword=""
        try:
            self.conn = pymysql.connect(host=myhost, db=mydb,user=myuser,password=mypassword)
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Connection Error","Database connection Error : "+str(e),parent=self.window)

    def search_all_data(self):
        self.database_connection()
        try:
            qry = "select * from detail"
            row_count = self.curr.execute(qry)
            data = self.curr.fetchall()
            print(data)
            if(data):
              for row in data:
                  d=row[:8]+row[9:]
                  self.mytable.insert("",END,values=d)

        except Exception as e:
            messagebox.showerror("Query Error","Query Error : "+str(e),parent=self.window)



if __name__ == '__main__':
    d_window=Tk()
    Record1Class(d_window)
    d_window.mainloop()


